/* eslint-disable no-unused-vars */
import React, { useContext, useState } from 'react'
import './Main.css'
import { assets } from '../../assets/assets'
import { Context } from '../../context/Context'

const Main = () => {

  const { onSent,
    recentPrompt,
    showResult,
    loading,
    resultData,
    setInput,
    input
  } = useContext(Context);

  const [dropdowns, setDropdowns] = useState(null); 

  const handleDropdownChange = (event) => { 
    setDropdowns({ ...dropdowns, [event.target.name]: event.target.value });
  };


  return (
    <div className='main'>
      <div className="nav">
        <p>Build Assistance</p>
        <img src={assets.user_icon} alt="" />
      </div>
      <div className="main-container">
        {showResult
          ? <div className="result">
            <div className='result-title'>
              <img src={assets.user_icon} alt="" />
              <p>{recentPrompt}</p>
            </div>
            <div className="result-data">
  <img src={assets.devops_icon} alt="" />
  {loading
    ? <div className="loader">
      <hr className="animated-bg" />
      <hr className="animated-bg" />
      <hr className="animated-bg" />
    </div>
    : resultData.type === 'dropdowns' 
      ? <>
        <p>{resultData.message}</p>
        <select name="LOB" onChange={handleDropdownChange}>
          <option value="">Select LOB</option>
          <option value="option1">Option 1</option>
          <option value="option2">Option 2</option>
          <option value="option3">Option 3</option>
        </select>
        <select name="Product" onChange={handleDropdownChange}>
          <option value="">Select Product</option>
          <option value="option1">Option 1</option>
          <option value="option2">Option 2</option>
          <option value="option3">Option 3</option>
        </select>
        <select name="repo" onChange={handleDropdownChange}>
          <option value="">Select repo</option>
          <option value="option1">Option 1</option>
          <option value="option2">Option 2</option>
          <option value="option3">Option 3</option>
        </select>
        <select name="branch" onChange={handleDropdownChange}>
          <option value="">Select branch</option>
          <option value="option1">Option 1</option>
          <option value="option2">Option 2</option>
          <option value="option3">Option 3</option>
        </select>
      </>
      : <p dangerouslySetInnerHTML={{ __html: resultData }}></p>
  }
</div>

          </div>
          : <>
            <div className="greet">
              <p><span>Hello, User.</span></p>
              <p>How can I help you today?</p>
            </div>
            <div className="cards">
              <div className="card">
                <p>Do you want to know the Build Status</p>
                <img src={assets.bs_icon} alt="" />
              </div>
              <div className="card">
                <p>Provide the Report and Analysis of the Coverity Report</p>
                <img src={assets.bulb_icon} alt="" />
              </div>
              <div className="card">
                <p>What is the health of the application?</p>
                <img src={assets.message_icon} alt="" />
              </div>
              <div className="card">
                <p>How many lines of code are there?</p>
                <img src={assets.code_icon} alt="" />
              </div>
            </div>
          </>
        }



        <div className="main-bottom">
          <div className="search-box">
            <input onChange={(e) => setInput(e.target.value)} value={input} type="text" placeholder='Enter a prompt here' />
            <div>
              {input ? <img onClick={() => onSent()} src={assets.send_icon} width={30} alt="" /> : null}
            </div>
          </div>
          <p className="bottom-info">
            This is a prototype version of Build Assistance, Please check with actual information to verify. 
          </p>
        </div>
      </div>
    </div>
  )
}

export default Main
