import React, { useState, useRef, useEffect } from 'react';
import axios from 'axios';
import Modal from 'react-modal'; // Import the modal component
import './App.css';
import Profile from './assets/devops.png';
import user from './assets/user.png';
import send from './assets/send.png';
import watermark from './assets/watermark.png';
import Sidebar from './sidebar';

function App() {
  const [messages, setMessages] = useState([]);
  const [inputText, setInputText] = useState('');
  const [jenkinsFormData, setJenkinsFormData] = useState({ LOB: '', Product: '', Repo: '', Branch: '' });
  const [coverityFormData, setCoverityFormData] = useState({ projectId: '' });
  const [healthFormData, setHealthFormData] = useState({ project_key: '', branch: '' });
  const [suggestionsVisible, setSuggestionsVisible] = useState(false);
  const [modalIsOpen, setModalIsOpen] = useState(false); // State to control the modal
  const [modalType, setModalType] = useState(''); // State to control the type of modal (Jenkins, Coverity, Health)
  const [submittingForm, setSubmittingForm] = useState(false); // State to track form submission
  const chatRef = useRef(null);

  useEffect(() => {
    // Scroll to the bottom of the chat area when messages change
    if (chatRef.current) {
      chatRef.current.scrollTop = chatRef.current.scrollHeight;
    }
    // if (messages.length === 0) {
    //   setMessages([{ text: "kcjbv", sender: 'bot' }]); // Empty message to reserve space for the watermark
    // }
  }, [messages]);

  axios.defaults.xsrfCookieName = 'csrftoken';
  axios.defaults.xsrfHeaderName = 'X-CSRFToken';

  const handleCancel = () => {
    // Clear form data
    setJenkinsFormData({ LOB: '', Product: '', Repo: '', Branch: '' });
    setCoverityFormData({ projectId: '' });
    setHealthFormData({ project_key: '', branch: '' });
    // Close the modal
    setModalIsOpen(false);
    // Prompt the user to select a suggestion again
    setSuggestionsVisible(true);
    // Reset modal type
    setModalType('');
    // Reset submittingForm state
    setSubmittingForm(false);
  };

  const isJenkinsFormComplete = () => {
    return jenkinsFormData.LOB !== '' && jenkinsFormData.Product !== '' && jenkinsFormData.Repo !== '' && jenkinsFormData.Branch !== '';
  };

  const isCoverityFormComplete = () => {
    return coverityFormData.projectId !== '';
  };

  const isHealthFormComplete = () => {
    return healthFormData.project_key !== '' && healthFormData.branch !== '';
  };

  const sendJenkinsDetailsToBackend = async () => {
    // Implementation for sending Jenkins status details to backend
    try {
      const { LOB, Product, Repo, Branch } = jenkinsFormData;
      const url = `http://localhost:8000/api/buildstatus/?LOB=${LOB}&Repo=${Repo}&Product=${Product}&Branch=${Branch}`;
      setModalIsOpen(false);
      const response = await axios.get(url, {
        headers: {
          'Content-Type': 'application/json'
        }
      });
      const responseData = response.data;

      // Extract project score and score description from the response data
      const buildstatus = responseData['build status'];

      // Construct messages for project score and score description with bold formatting
      const buildstatusMessage = `Build Status: ${buildstatus}`;

      // Create message objects for project score and score description
      // const buildstatusMessageobj = { text: buildstatusMessage, sender: 'bot', isHtml: true };
      const newMessages = [...messages, { text: <strong>{buildstatusMessage}</strong>, sender: 'bot' }];

      // Update the messages array with the project score and score description messages
      // setMessages(prevMessages => [...prevMessages, buildstatusMessageobj]);
      setMessages(newMessages);

      // Reset form data after sending details
      setJenkinsFormData({ LOB: '', Product: '', Repo: '', Branch: '' });
      setModalIsOpen(false);
    } catch (error) {
      console.error('Error sending details to backend:', error);
      const errorMessage = 'Error sending details to backend. Please try again later.';
      const newMessages = [...messages, { text: errorMessage, sender: 'bot' }];
      setMessages(newMessages);
    }
  };

  const sendCoverityDetailsToBackend = async () => {
    // Implementation for sending Coverity status details to backend
    try {
      const { projectId } = coverityFormData;
      const url = `http://localhost:8000/api/coverity/?projectId=${projectId}`;
      setModalIsOpen(false);
      const response = await axios.get(url, {
        headers: {
          'Content-Type': 'application/json'
        }
      });
      console.log('Response from backend:', response.data); // Check the response from the backend

      // Extract only the "High", "Medium", and "Low" counts from the response
      const { High, Medium, Low } = response.data.impact_counts;

      // // Construct a single message for all impact counts with bold formatting
      // const impactCountsMessage = `<strong>High:</strong> ${High}, <strong>Medium:</strong> ${Medium}, <strong>Low:</strong> ${Low}`;

      // // Create a message object for the impact counts
      // const newMessage = { text: impactCountsMessage, sender: 'bot', isHtml: true };
      //         const highMessage = `High: ${High}`;
      // const mediumMessage = `Medium: ${Medium}`;
      // const lowMessage = `Low: ${Low}`;

      const combinedMessage = `High: ${High}<br>Medium: ${Medium}<br>Low: ${Low}`;

      const newMessages = [
        ...messages,
        // { text: <strong>{combinedMessage}</strong>, sender: 'bot' }
        { text: <div dangerouslySetInnerHTML={{ __html: `<strong>${combinedMessage}</strong>` }} />, sender: 'bot' }
      ];


      // Update the messages array with the impact count message
      // setMessages(prevMessages => [...prevMessages, newMessage]);
      setMessages(newMessages);

      // Reset form data after sending details
      setCoverityFormData({ projectId: '' });
      setModalIsOpen(false);
    } catch (error) {
      console.error('Error sending details to backend:', error);
      const errorMessage = 'Error sending details to backend. Please try again later.';
      const newMessages = [...messages, { text: errorMessage, sender: 'bot' }];
      setMessages(newMessages);
    }
  };


  const sendHealthDetailsToBackend = async () => {
    try {
      const { project_key, branch } = healthFormData;
      const url = `http://localhost:8000/api/healthcheck/?project_key=${project_key}&branch=${branch}`;
      setModalIsOpen(false);
      const response = await axios.get(url, {
        headers: {
          'Content-Type': 'application/json'
        }
      });

      const responseData = response.data;

      // Mapping between metric names and desired display names
      const metricMappings = {
        bugs: 'Bugs',
        vulnerabilities: 'Vulnerabilities',
        code_smells: 'Code Smells',
        coverage: 'Coverage'
      };

      // Extract metrics from the responseData array and format them as a single response
      let formattedMetrics = '';
      responseData.metrics.forEach((metric, index) => {
        // Split the metric string into name and value
        const [metricName, metricValue] = metric.split(': ');
        // Map the metric name to the desired display name
        const displayName = metricMappings[metricName] || metricName;
        // Format the metric value with newline character
        formattedMetrics += `${displayName}: ${metricValue},`;
        // Add newline character if it's not the last metric
        if (index !== responseData.metrics.length - 1) {
          formattedMetrics += '\n';
        }
      });

      // Update the messages array with the formatted metrics as a single response
      const newMessages = [...messages, { text: <strong>{formattedMetrics}</strong>, sender: 'bot' }];
      setMessages(newMessages);

      // Reset form data after sending details
      setHealthFormData({ project_key: '', branch: '' });
      setModalIsOpen(false);
    } catch (error) {
      console.error('Error sending details to backend:', error);
      const errorMessage = 'Error sending details to backend. Please try again later.';
      setMessages(prevMessages => [...prevMessages, { text: errorMessage, sender: 'bot' }]);
    }
  };

  const handleSendMessage = async (suggestion, autoSend = false) => {
    // Trim input text
    const trimmedInputText = inputText.trim();

    if (suggestion) {
      setInputText(suggestion); // Set input text to the selected suggestion
      setModalType(suggestion.toLowerCase()); // Set modal type based on suggestion
    }

    if (trimmedInputText === '') return;

    try {
      let newMessages = [...messages, { text: inputText, sender: 'user' }];

      if (trimmedInputText === 'hi') {
        // Greeting message
        const greetingMessage = "Hello! I'm your assistant. How can I assist you today?";
        newMessages.push({ text: greetingMessage, sender: 'bot' });
        setSuggestionsVisible(true);
      } else if (suggestionsVisible && !submittingForm) {
        newMessages.push({ text: `You selected: ${inputText}`, sender: 'bot' });
        setSuggestionsVisible(false);
        setModalIsOpen(true); // Open the modal to collect details
      } else {
        // Unknown command
        const unknownMessage = "Sorry, I didn't understand that. Could you please rephrase your request?";
        newMessages.push({ text: unknownMessage, sender: 'bot' });
        // Show suggestions
        setSuggestionsVisible(true);
      }

      // Update state
      setMessages(newMessages);
      setInputText('');

      // Automatically send the message if autoSend is true
      if (autoSend) {
        handleSendMessage();
      }
    } catch (error) {
      console.error('Error sending message:', error);
      setMessages([...messages, { text: `Error: ${error.message}`, sender: 'bot' }]);
    }
  };

  return (
    <>
    <div className="app">
        <div className="chat-container">
          <div className="chat" ref={chatRef}>
            <div className="message-container">
              {messages.map((message, index) => (
                <div key={index} className={`message ${message.sender}`}>
                  {message.isHtml ? (
                    <span dangerouslySetInnerHTML={{ __html: message.text }} />
                  ) : (
                    <>
                      {message.sender !== 'user' ? <img className="profile-icon" src={Profile} alt='' /> : <img className="profile-icon" src={user} alt='' />}
                      <span>{message.text}</span>
                    </>
                  )}
                </div>
              ))}
              {messages.length === 0 && (
                <div className="watermark">
                  {/* <img src={watermark} alt="Build Assistant Logo" className="watermark-image" /> */}
                  <div className="watermark-text">
                    <h2>Welcome to Build Assistant!</h2>
                    <p>Start a conversation to get assistance with Jenkins status, Coverity status, or health checks.</p>
                  </div>
                </div>
              )}

            </div>
          </div>
          <div className="input-container">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
              placeholder="Type your message..."
              className="input" />
            <button onClick={() => handleSendMessage()} className="send-icon">
              <img className="send-icon" src={send} alt='' />
            </button>
          </div>
          {/* Suggestions */}
          {suggestionsVisible && (
            <div className="suggestions">
              <button className="suggestion" onClick={() => handleSendMessage('Jenkins status')}>
                Jenkins status
              </button>
              <button className="suggestion" onClick={() => handleSendMessage('Coverity status')}>
                Coverity status
              </button>
              <button className="suggestion" onClick={() => handleSendMessage('Health check')}>
                Health check
              </button>
            </div>
          )}
          {/* Modals */}
          {/* Jenkins Status Modal */}
          <Modal
            isOpen={modalIsOpen && modalType === 'jenkins status'}
            onRequestClose={() => setModalIsOpen(false)}
            contentLabel="Jenkins Status Form"
            shouldCloseOnOverlayClick={false}
          >
            <h2>Jenkins Status Form</h2>
            <label htmlFor="lob">LOB:</label>
            <select id="lob" value={jenkinsFormData.LOB} onChange={(e) => setJenkinsFormData({ ...jenkinsFormData, LOB: e.target.value })} required>
              <option value="">Select an option</option>
              <option value="LSS">LSS</option>
              <option value="option2">Option 2</option>
              <option value="option3">Option 3</option>
            </select>

            {/* <label htmlFor="product">Product:</label>
    <select id="product" value={jenkinsFormData.Product} onChange={(e) => setJenkinsFormData({ ...jenkinsFormData, Product: e.target.value })} required>
      <option value="">Select an option</option>
      <option value="option1">Option 1</option>
      <option value="option2">Option 2</option>
      <option value="option3">Option 3</option>
    </select>

    <label htmlFor="repo">Repo:</label>
    <select id="repo" value={jenkinsFormData.Repo} onChange={(e) => setJenkinsFormData({ ...jenkinsFormData, Repo: e.target.value })} required>
      <option value="">Select an option</option>
      <option value="option1">Option 1</option>
      <option value="option2">Option 2</option>
      <option value="option3">Option 3</option>
    </select>

    <label htmlFor="branch">Branch:</label>
    <select id="branch" value={jenkinsFormData.Branch} onChange={(e) => setJenkinsFormData({ ...jenkinsFormData, Branch: e.target.value })} required>
      <option value="">Select a Branch</option>
      <option value="branch1">Branch 1</option>
      <option value="branch2">Branch 2</option>
      <option value="branch3">Branch 3</option>
    </select> */}
            {jenkinsFormData.LOB === 'LSS' && (
              <div>
                <label htmlFor="product">Product:</label>
                <select id="product" value={jenkinsFormData.Product} onChange={(e) => setJenkinsFormData({ ...jenkinsFormData, Product: e.target.value })} required>
                  <option value="">Select a Product</option>
                  <option value="DigitalPrime">DigitalPrime</option>
                  <option value="product2">Product 2</option>
                  {/* Add more product options here if needed */}
                </select>
              </div>
            )}

            {jenkinsFormData.Product === 'DigitalPrime' && (
              <div>
                <label htmlFor="repo">Repo:</label>
                <select id="repo" value={jenkinsFormData.Repo} onChange={(e) => setJenkinsFormData({ ...jenkinsFormData, Repo: e.target.value })} required>
                  <option value="">Select a Repo</option>
                  <option value="DigitalPrime_Service">DigitalPrime_Service</option>
                  <option value="DigitalPrime_UI">DigitalPrime_UI</option>
                  {/* Add more product options here if needed */}
                </select>
              </div>
            )}

            {jenkinsFormData.Repo === 'DigitalPrime_Service' && (
              <div>
                <label htmlFor="branch">Branch:</label>
                <select id="branch" value={jenkinsFormData.Branch} onChange={(e) => setJenkinsFormData({ ...jenkinsFormData, Branch: e.target.value })} required>
                  <option value="">Select a Product</option>
                  <option value="master">master</option>
                  <option value="develop">develop</option>
                  {/* Add more product options here if needed */}
                </select>
              </div>
            )}
            {jenkinsFormData.Repo === 'DigitalPrime_UI' && (
              <div>
                <label htmlFor="branch">Branch:</label>
                <select id="branch" value={jenkinsFormData.Branch} onChange={(e) => setJenkinsFormData({ ...jenkinsFormData, Branch: e.target.value })} required>
                  <option value="">Select a Product</option>
                  <option value="master">master</option>
                  <option value="develop">develop</option>
                  {/* Add more product options here if needed */}
                </select>
              </div>
            )}

            <button onClick={sendJenkinsDetailsToBackend} disabled={!isJenkinsFormComplete()}>
              Submit
            </button>
            <button onClick={() => handleCancel()}>Cancel</button>
          </Modal>
          {/* // Inside the return statement of the component */}

          {modalIsOpen && modalType === 'coverity status' && (
            <Modal
              isOpen={modalIsOpen && modalType === 'coverity status'}
              onRequestClose={() => setModalIsOpen(false)}
              contentLabel="Coverity Status Form"
              shouldCloseOnOverlayClick={false}
            >
              <h2>Coverity Status Form</h2>
              <label htmlFor="projectId">Project ID:</label>
              <select id="projectId" value={coverityFormData.projectId} onChange={(e) => setCoverityFormData({ ...coverityFormData, projectId: e.target.value })} required>
                <option value="">Select a Project ID</option>
                <option value="25027">25027</option>
                <option value="project2">Project 2</option>
                <option value="project3">Project 3</option>
              </select>
              <button onClick={sendCoverityDetailsToBackend} disabled={!isCoverityFormComplete()}>
                Submit
              </button>
              <button onClick={() => handleCancel()}>Cancel</button>
            </Modal>
          )}

          {modalIsOpen && modalType === 'health check' && (
            <Modal
              isOpen={modalIsOpen && modalType === 'health check'}
              onRequestClose={() => setModalIsOpen(false)}
              contentLabel="Health Check Form"
              shouldCloseOnOverlayClick={false}
            >
              <h2>Health Check Form</h2>
              <label htmlFor="project_key">Project Key:</label>
              <select id="project_key" value={healthFormData.project_key} onChange={(e) => setHealthFormData({ ...healthFormData, project_key: e.target.value })} required>
                <option value="">Select a Project Key</option>
                <option value="FDICC">FDICC</option>
                <option value="key2">Key 2</option>
                <option value="key3">Key 3</option>
              </select>
              {/* <label htmlFor="branch">Branch:</label>
    <select id="branch" value={healthFormData.branch} onChange={(e) => setHealthFormData({ ...healthFormData, branch: e.target.value })} required>
      <option value="">Select a Branch</option>
      <option value="branch1">Branch 1</option>
      <option value="branch2">Branch 2</option>
      <option value="branch3">Branch 3</option>
    </select> */}
              {healthFormData.project_key === 'FDICC' && (
                <div>
                  <label htmlFor="branch">Branch:</label>
                  <select id="branch" value={healthFormData.branch} onChange={(e) => setHealthFormData({ ...healthFormData, branch: e.target.value })} required>
                    <option value="">Select a Product</option>
                    <option value="DEVOPS_PILOT_03">DEVOPS_PILOT_03</option>
                    <option value="Branch2">Branch 2</option>
                    {/* Add more product options here if needed */}
                  </select>
                </div>
              )}
              <button onClick={sendHealthDetailsToBackend} disabled={!isHealthFormComplete()}>
                Submit
              </button>
              <button onClick={() => handleCancel()}>Cancel</button>
            </Modal>
          )}

        </div>
      </div></>
  );
}

export default App;
