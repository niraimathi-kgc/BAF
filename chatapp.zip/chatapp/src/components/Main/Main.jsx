/* eslint-disable no-unused-vars */
import React, { useContext, useEffect, useRef, useState } from 'react'
import './Main.css'
import { assets } from '../../assets/assets'
import { Context } from '../../context/Context'
import { Box, Button, FormControl, InputLabel, MenuItem, Modal, Select, TextField, Typography, styled } from '@mui/material'
import axios from 'axios'

export const InputNextButton = styled(Button)({
  // margin: '0 10px',
  textTransform: 'none',
  backgroundColor: '#12498a',
  ':hover': {
    backgroundColor: '#12498a'
  }
})

export const InputBackButton = styled(Button)({
  border: '1px solid #12498a',
  margin: '0 10px',
  textTransform: 'none',
  color: '#12498a',
  ':hover': {
    border: '1px solid #12498a',
  }
})

export const DropDown = styled(Select)({
  '& .MuiOutlinedInput-notchedOutline': {
    borderColor: '#c4c4c4',
    borderWidth: '1.5px',
    borderRadius: '12px',
  },
  '& .MuiInputBase-input': {
    padding: '9.5px 14px',
    fontSize: "14px",
  },
})

export const StyledInputLabel = styled(InputLabel)({
  top: "-4.5px",
  left: "5px",
  fontSize: '14px',
  "& .Mui-focused": {
    color: '#00000099',
  }
});


const Main = () => {
  const { onSent,
    recentPrompt,
    showResult,
    loading,
    resultData,
    setInput,
    input, buildStatus, setBuildStatus
  } = useContext(Context);

  const [dropdowns, setDropdowns] = useState(null);
  // State to track form submission
  const [messages, setMessages] = useState([]);
  const [inputText, setInputText] = useState('');
  const [jenkinsFormData, setJenkinsFormData] = useState({ LOB: '', Product: '', Repo: '', Branch: '' });
  const [coverityFormData, setCoverityFormData] = useState({ projectId: '' });
  const [healthFormData, setHealthFormData] = useState({ project_key: '', branch: '' });
  const [suggestionsVisible, setSuggestionsVisible] = useState(false);
  const [modalIsOpen, setModalIsOpen] = useState(false); // State to control the modal
  const [modalType, setModalType] = useState(''); // State to control the type of modal (Jenkins, Coverity, Health)
  const [submittingForm, setSubmittingForm] = useState(false); // State to track form submission
  const chatRef = useRef(null);

  useEffect(() => {
    // Scroll to the bottom of the chat area when messages change
    if (chatRef.current) {
      chatRef.current.scrollTop = chatRef.current.scrollHeight;
    }
    // if (messages.length === 0) {
    //   setMessages([{ text: "kcjbv", sender: 'bot' }]); // Empty message to reserve space for the watermark
    // }
  }, [messages]);

  axios.defaults.xsrfCookieName = 'csrftoken';
  axios.defaults.xsrfHeaderName = 'X-CSRFToken';

  const handleCancel = () => {
    // Clear form data
    setJenkinsFormData({ LOB: '', Product: '', Repo: '', Branch: '' });
    setCoverityFormData({ projectId: '' });
    setHealthFormData({ project_key: '', branch: '' });
    // Close the modal
    setModalIsOpen(false);
    // Prompt the user to select a suggestion again
    setSuggestionsVisible(true);
    // Reset modal type
    setModalType('');
    // Reset submittingForm state
    setSubmittingForm(false);
  };

  const isJenkinsFormComplete = () => {
    return jenkinsFormData?.LOB !== '' && jenkinsFormData?.Product !== '' && jenkinsFormData?.Repo !== '' && jenkinsFormData?.Branch !== '';
  };

  const isCoverityFormComplete = () => {
    return coverityFormData.projectId !== '';
  };

  const isHealthFormComplete = () => {
    return healthFormData.project_key !== '' && healthFormData.branch !== '';
  };

  const sendJenkinsDetailsToBackend = async () => {
    // Implementation for sending Jenkins status details to backend
    try {
      const { LOB, Product, Repo, Branch } = jenkinsFormData;
      const url = `http://localhost:8000/api/buildstatus/?LOB=${LOB}&Repo=${Repo}&Product=${Product}&Branch=${Branch}`;
      setModalIsOpen(false);
      const response = await axios.get(url, {
        headers: {
          'Content-Type': 'application/json'
        }
      });
      const responseData = response.data;

      // Extract project score and score description from the response data
      const buildstatus = responseData['build status'];

      // Construct messages for project score and score description with bold formatting
      const buildstatusMessage = `Build Status: ${buildstatus}`;

      // Create message objects for project score and score description
      // const buildstatusMessageobj = { text: buildstatusMessage, sender: 'bot', isHtml: true };
      const newMessages = [...messages, { text: <strong>{buildstatusMessage}</strong>, sender: 'bot' }];

      // Update the messages array with the project score and score description messages
      // setMessages(prevMessages => [...prevMessages, buildstatusMessageobj]);
      setMessages(newMessages);

      // Reset form data after sending details
      setJenkinsFormData({ LOB: '', Product: '', Repo: '', Branch: '' });
      setModalIsOpen(false);
    } catch (error) {
      console.error('Error sending details to backend:', error);
      const errorMessage = 'Error sending details to backend. Please try again later.';
      const newMessages = [...messages, { text: errorMessage, sender: 'bot' }];
      setMessages(newMessages);
    }
  };

  const sendCoverityDetailsToBackend = async () => {
    // Implementation for sending Coverity status details to backend
    try {
      const { projectId } = coverityFormData;
      const url = `http://localhost:8000/api/coverity/?projectId=${projectId}`;
      setModalIsOpen(false);
      const response = await axios.get(url, {
        headers: {
          'Content-Type': 'application/json'
        }
      });
      console.log('Response from backend:', response.data); // Check the response from the backend

      // Extract only the "High", "Medium", and "Low" counts from the response
      const { High, Medium, Low } = response.data.impact_counts;

      // // Construct a single message for all impact counts with bold formatting
      // const impactCountsMessage = `<strong>High:</strong> ${High}, <strong>Medium:</strong> ${Medium}, <strong>Low:</strong> ${Low}`;

      // // Create a message object for the impact counts
      // const newMessage = { text: impactCountsMessage, sender: 'bot', isHtml: true };
      //         const highMessage = `High: ${High}`;
      // const mediumMessage = `Medium: ${Medium}`;
      // const lowMessage = `Low: ${Low}`;

      const combinedMessage = `High: ${High}<br>Medium: ${Medium}<br>Low: ${Low}`;

      const newMessages = [
        ...messages,
        // { text: <strong>{combinedMessage}</strong>, sender: 'bot' }
        { text: <div dangerouslySetInnerHTML={{ __html: `<strong>${combinedMessage}</strong>` }} />, sender: 'bot' }
      ];


      // Update the messages array with the impact count message
      // setMessages(prevMessages => [...prevMessages, newMessage]);
      setMessages(newMessages);

      // Reset form data after sending details
      setCoverityFormData({ projectId: '' });
      setModalIsOpen(false);
    } catch (error) {
      console.error('Error sending details to backend:', error);
      const errorMessage = 'Error sending details to backend. Please try again later.';
      const newMessages = [...messages, { text: errorMessage, sender: 'bot' }];
      setMessages(newMessages);
    }
  };


  const sendHealthDetailsToBackend = async () => {
    try {
      const { project_key, branch } = healthFormData;
      const url = `http://localhost:8000/api/healthcheck/?project_key=${project_key}&branch=${branch}`;
      setModalIsOpen(false);
      const response = await axios.get(url, {
        headers: {
          'Content-Type': 'application/json'
        }
      });

      const responseData = response.data;

      // Mapping between metric names and desired display names
      const metricMappings = {
        bugs: 'Bugs',
        vulnerabilities: 'Vulnerabilities',
        code_smells: 'Code Smells',
        coverage: 'Coverage'
      };

      // Extract metrics from the responseData array and format them as a single response
      let formattedMetrics = '';
      responseData.metrics.forEach((metric, index) => {
        // Split the metric string into name and value
        const [metricName, metricValue] = metric.split(': ');
        // Map the metric name to the desired display name
        const displayName = metricMappings[metricName] || metricName;
        // Format the metric value with newline character
        formattedMetrics += `${displayName}: ${metricValue},`;
        // Add newline character if it's not the last metric
        if (index !== responseData.metrics.length - 1) {
          formattedMetrics += '\n';
        }
      });

      // Update the messages array with the formatted metrics as a single response
      const newMessages = [...messages, { text: <strong>{formattedMetrics}</strong>, sender: 'bot' }];
      setMessages(newMessages);

      // Reset form data after sending details
      setHealthFormData({ project_key: '', branch: '' });
      setModalIsOpen(false);
    } catch (error) {
      console.error('Error sending details to backend:', error);
      const errorMessage = 'Error sending details to backend. Please try again later.';
      setMessages(prevMessages => [...prevMessages, { text: errorMessage, sender: 'bot' }]);
    }
  };

  const handleSendMessage = async (suggestion, autoSend = false) => {
    // Trim input text
    const trimmedInputText = inputText.trim();

    if (suggestion) {
      setInputText(suggestion); // Set input text to the selected suggestion
      setModalType(suggestion.toLowerCase()); // Set modal type based on suggestion
    }

    if (trimmedInputText === '') return;

    try {
      let newMessages = [...messages, { text: inputText, sender: 'user' }];

      if (trimmedInputText === 'hi') {
        // Greeting message
        const greetingMessage = "Hello! I'm your assistant. How can I assist you today?";
        newMessages.push({ text: greetingMessage, sender: 'bot' });
        setSuggestionsVisible(true);
      } else if (suggestionsVisible && !submittingForm) {
        newMessages.push({ text: `You selected: ${inputText}`, sender: 'bot' });
        setSuggestionsVisible(false);
        setModalIsOpen(true); // Open the modal to collect details
      } else {
        // Unknown command
        const unknownMessage = "Sorry, I didn't understand that. Could you please rephrase your request?";
        newMessages.push({ text: unknownMessage, sender: 'bot' });
        // Show suggestions
        setSuggestionsVisible(true);
      }

      // Update state
      setMessages(newMessages);
      setInputText('');

      // Automatically send the message if autoSend is true
      if (autoSend) {
        handleSendMessage();
      }
    } catch (error) {
      console.error('Error sending message:', error);
      setMessages([...messages, { text: `Error: ${error.message}`, sender: 'bot' }]);
    }
  };

  const modalStyles = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 500,
    bgcolor: '#f0f4f9',
    borderRadius: "15px",
    outline: "none",
    p: 2.5,
  };



  return (
    <div className='main'>
      <div className="nav">
        <p>Build Assistance</p>
        <img src={assets.user_icon} alt="" />
      </div>
      <div className="main-container">
        {showResult
          ? <div className="result">
            <div className='result-title'>
              <img src={assets.user_icon} alt="" />
              <p>{recentPrompt}</p>
            </div>
            <div className="result-data">
              <img src={assets.devops_icon} alt="" />
              {loading
                ? <div className="loader">
                  <hr className="animated-bg" />
                  <hr className="animated-bg" />
                  <hr className="animated-bg" />
                </div>
                : resultData.type === 'dropdowns'
                  ? <>
                    <p>{resultData.message}</p>
                    <select name="LOB" onChange={handleDropdownChange}>
                      <option value="">Select LOB</option>
                      <option value="option1">Option 1</option>
                      <option value="option2">Option 2</option>
                      <option value="option3">Option 3</option>
                    </select>
                    <select name="Product" onChange={handleDropdownChange}>
                      <option value="">Select Product</option>
                      <option value="option1">Option 1</option>
                      <option value="option2">Option 2</option>
                      <option value="option3">Option 3</option>
                    </select>
                    <select name="repo" onChange={handleDropdownChange}>
                      <option value="">Select repo</option>
                      <option value="option1">Option 1</option>
                      <option value="option2">Option 2</option>
                      <option value="option3">Option 3</option>
                    </select>
                    <select name="branch" onChange={handleDropdownChange}>
                      <option value="">Select branch</option>
                      <option value="option1">Option 1</option>
                      <option value="option2">Option 2</option>
                      <option value="option3">Option 3</option>
                    </select>
                  </>
                  : <p dangerouslySetInnerHTML={{ __html: resultData }}></p>
              }
            </div>
          </div>
          : <>
            <div className="greet">
              <p><span>Hello, User.</span></p>
              <p>How can I help you today?</p>
            </div>
            <div className="cards">
              <div className="card">
                <p onClick={() => { setModalIsOpen(true); setModalType("jenkins status") }}>Do you want to know the Build Status</p>
                <img src={assets.bs_icon} alt="" />
              </div>
              <div className="card">
                <p onClick={() => { setModalIsOpen(true); setModalType("coverity status") }}>Provide the Report and Analysis of the Coverity Report</p>
                <img src={assets.bulb_icon} alt="" />
              </div>
              <div className="card">
                <p onClick={() => { setModalIsOpen(true); setModalType("health check") }}>What is the health of the application?</p>
                <img src={assets.message_icon} alt="" />
              </div>
              <div className="card">
                <p>How many lines of code are there?</p>
                <img src={assets.code_icon} alt="" />
              </div>
            </div>
          </>
        }

        <div className="main-bottom">
          <div className="search-box">
            <input onChange={(e) => setInput(e.target.value)} value={input} type="text" placeholder='Enter a prompt here' />
            <div>
              {input ? <img onClick={() => onSent()} src={assets.send_icon} width={30} alt="" /> : null}
            </div>
          </div>
          <p className="bottom-info">
            This is a prototype version of Build Assistance, Please check with actual information to verify.
          </p>
        </div>
      </div>
      <Modal open={modalIsOpen && modalType === 'jenkins status'}>
        <Box sx={{ ...modalStyles }}>
          <Typography textAlign={"center"} sx={{ fontSize: "15px", fontWeight: "bold" }}>Jenkins Status Form</Typography>
          {/* <label htmlFor="lob">LOB:</label>
            <select id="lob" value={jenkinsFormData?.LOB} onChange={(e) => setJenkinsFormData({ ...jenkinsFormData, LOB: e.target.value })} required>
              <option value="">Select an option</option>
              <option value="LSS">LSS</option>
              <option value="option2">Option 2</option>
              <option value="option3">Option 3</option>
            </select> */}
          <FormControl sx={{ width: "95%", margin: ' 15px 0 15px 2%' }} className="select">
            <StyledInputLabel id="demo-simple-select-label">
              {"LOB"}
            </StyledInputLabel>
            <DropDown
              name="lob"
              value={jenkinsFormData?.LOB}
              onChange={(e) => setJenkinsFormData({ ...jenkinsFormData, LOB: e.target.value })}
              labelId="demo-simple-select-label"

            >
              {/* <MenuItem value={"Select an option"}>Select an option</MenuItem> */}
              <MenuItem value={"LSS"}>LSS</MenuItem>
              <MenuItem value={"option2"}>Option 2</MenuItem>
              <MenuItem value={"option3"}>Option 3</MenuItem>
            </DropDown>
          </FormControl>

          {jenkinsFormData.LOB === 'LSS' && (
            <div>
              {/* <label htmlFor="product">Product:</label>
                <select id="product" value={jenkinsFormData.Product} onChange={(e) => setJenkinsFormData({ ...jenkinsFormData, Product: e.target.value })} required>
                  <option value="">Select a Product</option>
                  <option value="DigitalPrime">DigitalPrime</option>
                  <option value="product2">Product 2</option>
                </select> */}

              <FormControl sx={{ width: "95%", margin: ' 15px 0 15px 2%' }} className="select">
                <StyledInputLabel id="demo-simple-select-label">
                  {"Product"}
                </StyledInputLabel>
                <DropDown
                  name="product"
                  value={jenkinsFormData?.Product}
                  onChange={(e) => setJenkinsFormData({ ...jenkinsFormData, Product: e.target.value })}
                  labelId="demo-simple-select-label"
                >
                  {/* <MenuItem value={""}>Select an Product</MenuItem> */}
                  <MenuItem value={"DigitalPrime"}>DigitalPrime</MenuItem>
                  <MenuItem value={"product2"}>Product 2</MenuItem>
                </DropDown>
              </FormControl>
            </div>
          )}

          {jenkinsFormData.Product === 'DigitalPrime' && (
            <div>
              {/* <label htmlFor="repo">Repo:</label>
                <select id="repo" value={jenkinsFormData?.Repo} onChange={(e) => setJenkinsFormData({ ...jenkinsFormData, Repo: e.target.value })} required>
                  <option value="">Select a Repo</option>
                  <option value="DigitalPrime_Service">DigitalPrime_Service</option>
                  <option value="DigitalPrime_UI">DigitalPrime_UI</option>
                </select> */}

              <FormControl sx={{ width: "95%", margin: ' 15px 0 15px 2%' }} className="select">
                <StyledInputLabel id="demo-simple-select-label">
                  {"Repo"}
                </StyledInputLabel>
                <DropDown
                  name="product"
                  value={jenkinsFormData?.Repo}
                  onChange={(e) => setJenkinsFormData({ ...jenkinsFormData, Repo: e.target.value })}
                  labelId="demo-simple-select-label"
                >
                  {/* <MenuItem value={""}>Select a Repo</MenuItem> */}
                  <MenuItem value={"DigitalPrime_Service"}>DigitalPrime_Service</MenuItem>
                  <MenuItem value={"DigitalPrime_UI"}>DigitalPrime_UI</MenuItem>
                </DropDown>
              </FormControl>
            </div>
          )}

          {jenkinsFormData.Repo === 'DigitalPrime_Service' && (
            <div>
              {/* <label htmlFor="branch">Branch:</label>
                <select id="branch" value={jenkinsFormData?.Branch} onChange={(e) => setJenkinsFormData({ ...jenkinsFormData, Branch: e.target.value })} required>
                  <option value="">Select a Product</option>
                  <option value="master">master</option>
                  <option value="develop">develop</option>
                </select> */}



              <FormControl sx={{ width: "95%", margin: ' 15px 0 15px 2%' }} className="select">
                <StyledInputLabel id="demo-simple-select-label">
                  {"Branch"}
                </StyledInputLabel>
                <DropDown
                  name="branch"
                  value={jenkinsFormData?.Branch}
                  onChange={(e) => setJenkinsFormData({ ...jenkinsFormData, Branch: e.target.value })}
                  labelId="demo-simple-select-label"
                >
                  {/* <MenuItem value={""}>Select a Repo</MenuItem> */}
                  <MenuItem value={"master"}>Master</MenuItem>
                  <MenuItem value={"dev"}>Dev</MenuItem>
                </DropDown>
              </FormControl>

            </div>
          )}
          {jenkinsFormData.Repo === 'DigitalPrime_UI' && (
            <div>
              {/* <label htmlFor="branch">Branch:</label>
                <select id="branch" value={jenkinsFormData?.Branch} onChange={(e) => setJenkinsFormData({ ...jenkinsFormData, Branch: e.target.value })} required>
                  <option value="">Select a Product</option>
                  <option value="master">master</option>
                  <option value="develop">develop</option>
                </select> */}

              <FormControl sx={{ width: "95%", margin: ' 15px 0 15px 2%' }} className="select">
                <StyledInputLabel id="demo-simple-select-label">
                  {"Branch"}
                </StyledInputLabel>
                <DropDown
                  name="branch"
                  value={jenkinsFormData?.Branch}
                  onChange={(e) => setJenkinsFormData({ ...jenkinsFormData, Branch: e.target.value })}
                  labelId="demo-simple-select-label"
                >
                  {/* <MenuItem value={""}>Select a Repo</MenuItem> */}
                  <MenuItem value={"master"}>Master</MenuItem>
                  <MenuItem value={"dev"}>Dev</MenuItem>
                </DropDown>
              </FormControl>
            </div>
          )}
          {/* <button onClick={sendJenkinsDetailsToBackend} disabled={!isJenkinsFormComplete()}>
              Submit
            </button> */}
          <Box textAlign={"right"} marginRight={"16px"}>
            <InputBackButton onClick={() => handleCancel()}>Cancel</InputBackButton>
            <InputNextButton variant='contained' onClick={sendJenkinsDetailsToBackend} disabled={!isJenkinsFormComplete()}>Submit</InputNextButton>
          </Box>
          {/* <button >Cancel</button> */}
        </Box>
      </Modal>
      <Modal open={modalIsOpen && modalType === 'coverity status'}>
        <Box sx={{ ...modalStyles }}>
          <Typography textAlign={"center"} sx={{ fontSize: "15px", fontWeight: "bold" }}>Coverity Status Form</Typography>
          {/* <label htmlFor="projectId">Project ID:</label>
          <select id="projectId" value={coverityFormData?.projectId} onChange={(e) => setCoverityFormData({ ...coverityFormData, projectId: e.target.value })} required>
            <option value="">Select a Project ID</option>
            <option value="25027">25027</option>
            <option value="project2">Project 2</option>
            <option value="project3">Project 3</option>
          </select> */}

          <FormControl sx={{ width: "95%", margin: ' 15px 0 15px 2%' }} className="select">
            <StyledInputLabel id="demo-simple-select-label">
              {"Project ID"}
            </StyledInputLabel>
            <DropDown
              name="projectId"
              value={coverityFormData?.projectId}
              onChange={(e) => setCoverityFormData({ ...coverityFormData, projectId: e.target.value })}
              labelId="demo-simple-select-label"
            >
              {/* <MenuItem value={"Select an option"}>Select an option</MenuItem> */}
              <MenuItem value={"25027"}>25027</MenuItem>
              <MenuItem value={"project2"}>Project 2</MenuItem>
              <MenuItem value={"project3"}>Project 3</MenuItem>
            </DropDown>
          </FormControl>
          <Box textAlign={"right"} marginRight={"16px"}>
            <InputBackButton onClick={() => handleCancel()}>Cancel</InputBackButton>
            <InputNextButton variant='contained' onClick={sendCoverityDetailsToBackend} disabled={!isCoverityFormComplete()}>Submit</InputNextButton>
          </Box>
          {/* <button onClick={sendCoverityDetailsToBackend} disabled={!isCoverityFormComplete()}>
            Submit
          </button>
          <button onClick={() => handleCancel()}>Cancel</button> */}
        </Box>
      </Modal>
      <Modal
        open={modalIsOpen && modalType === 'health check'}
      >
        <Box sx={{ ...modalStyles }}>
          <Typography textAlign={"center"} sx={{ fontSize: "15px", fontWeight: "bold" }}>Health Check Form</Typography>
          {/* <label htmlFor="project_key">Project Key:</label>
          <select id="project_key" value={healthFormData.project_key} onChange={(e) => setHealthFormData({ ...healthFormData, project_key: e.target.value })} required>
            <option value="">Select a Project Key</option>
            <option value="FDICC">FDICC</option>
            <option value="key2">Key 2</option>
            <option value="key3">Key 3</option>
          </select> */}
          <FormControl sx={{ width: "95%", margin: ' 15px 0 15px 2%' }} className="select">
            <StyledInputLabel id="demo-simple-select-label">
              {"Project Key"}
            </StyledInputLabel>
            <DropDown
              name="project_key"
              value={healthFormData.project_key} onChange={(e) => setHealthFormData({ ...healthFormData, project_key: e.target.value })}
              labelId="demo-simple-select-label"
            >
              {/* <MenuItem value={"Select an option"}>Select an option</MenuItem> */}
              <MenuItem value={"FDICC"}>FDICC</MenuItem>
              <MenuItem value={"key2"}>Key 2</MenuItem>
              <MenuItem value={"key3"}>Key 3</MenuItem>
            </DropDown>
          </FormControl>

          {healthFormData.project_key === 'FDICC' && (
            <div>
              {/* <label htmlFor="branch">Branch:</label>
              <select id="branch" value={healthFormData.branch} onChange={(e) => setHealthFormData({ ...healthFormData, branch: e.target.value })} required>
                <option value="">Select a Product</option>
                <option value="DEVOPS_PILOT_03">DEVOPS_PILOT_03</option>
                <option value="Branch2">Branch 2</option>
              </select> */}

              <FormControl sx={{ width: "95%", margin: ' 15px 0 15px 2%' }} className="select">
            <StyledInputLabel id="demo-simple-select-label">
              {"Branch"}
            </StyledInputLabel>
            <DropDown
              name="branch"
              value={healthFormData.branch} onChange={(e) => setHealthFormData({ ...healthFormData, branch: e.target.value })}
              labelId="demo-simple-select-label"
            >
              {/* <MenuItem value={"Select an option"}>Select an option</MenuItem> */}
              <MenuItem value={"DEVOPS_PILOT_03"}>DEVOPS_PILOT_03</MenuItem>
              <MenuItem value={"Branch2"}>Branch 2</MenuItem>
            </DropDown>
          </FormControl>

            </div>
          )}
          {/* <button onClick={sendHealthDetailsToBackend} disabled={!isHealthFormComplete()}>
            Submit
          </button>
          <button onClick={() => handleCancel()}>Cancel</button> */}
          <Box textAlign={"right"} marginRight={"16px"}>
            <InputBackButton onClick={() => handleCancel()}>Cancel</InputBackButton>
            <InputNextButton variant='contained' onClick={sendHealthDetailsToBackend} disabled={!isHealthFormComplete()}>Submit</InputNextButton>
          </Box>
        </Box>
      </Modal>

    </div>
  )
}

export default Main
