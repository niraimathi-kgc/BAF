/* eslint-disable no-unused-vars */
import React, { useState } from 'react'
import Sidebar from './components/Sidebar/Sidebar'
import Main from './components/Main/Main'
import Form from './components/Form/form'

const App = () => {
  return (
    <>
      <Sidebar />
      <Main />
    </>
  )
}

export default App
