/* eslint-disable no-unused-vars */
import { createContext, useState } from "react";
import PropTypes from 'prop-types';
// import runChat from "../config/Config";

export const Context = createContext();

const commands = {
    'hello': () => 'Hello, how can I help you today?',
    'hi': () => 'Hello, how are you doing today, What can I help you with?',
    'build status': () => ({ type: 'dropdowns', message: 'Sure, Can you help me choose the LOB, Product, repo and branch.' }),
    // Add more commands here
};

async function runChat(prompt) {
    const command = commands[prompt.toLowerCase()];
    if (!command) {
        return 'Sorry, I did not understand that.';
    }
    try {
        return command();
    } catch (error) {
        console.error(error);
        return 'Sorry, something went wrong.';
    }
}

const ContextProvider = (props) => {
    const [prevPrompts, setPrevPrompts] = useState([]);
    const [input, setInput] = useState("");
    const [recentPrompt, setRecentPrompt] = useState("");
    const [showResult, setShowResult] = useState(false)
    const [loading, setLoading] = useState(false)
    const [resultData, setResultData] = useState("");
    const [buildStatus, setBuildStatus] = useState();

    function delayPara(index, nextWord) {
        setTimeout(function () {
            setResultData(prev => prev + nextWord)
        }, 75 * index);
    }

    const onSent = async (prompt) => {
        setResultData("");
        setLoading(true);
        setShowResult(true);
        let response;
        let timeoutId;

        timeoutId = setTimeout(() => {
            setLoading(false);
            setResultData("Sorry, Could not capture your response, will get back to you on this");
        }, 30000);

        if (prompt !== undefined) {
            response = await runChat(prompt);
            setRecentPrompt(prompt);
        } else {
            setPrevPrompts(prev => [...prev, input]);
            setRecentPrompt(input);
            response = await runChat(input);
        }
        clearTimeout(timeoutId);
        // Add a delay before processing the response
        setTimeout(() => {
            let responseArray = response.split('**');
            let newArray = "";
            for (let i = 0; i < responseArray.length; i++) {
                if (i === 0 || i % 2 !== 1) {
                    newArray += responseArray[i]
                }
                else {
                    newArray += "<b>" + responseArray[i] + "</b>"
                }
            }
            console.log(newArray);
            responseArray = newArray.split('*').join("</br>").split(" ");
            for (let i = 0; i < responseArray.length; i++) {
                const nextWord = responseArray[i];
                delayPara(i, nextWord + " ")
            }
            setLoading(false);
            setInput("");
        }, 1000); // Delay of 1 second
    }

    const newChat = async () => {
        setLoading(false);
        setShowResult(false);
    }

    const contextValue = {
        prevPrompts,
        setPrevPrompts,
        onSent,
        setRecentPrompt,
        recentPrompt,
        showResult,
        loading,
        resultData,
        input,
        setInput,
        setResultData,
        newChat,
        buildStatus,
        setBuildStatus,
        setShowResult
    }

    return (
        <Context.Provider value={contextValue}>
            {props.children}
        </Context.Provider>
    )
}

ContextProvider.propTypes = {
    children: PropTypes.node,
};

export default ContextProvider;