const commands = {
    'hello': () => 'Hello, how can I help you today?',
    'hi': () => 'Hello, how are you doing today, What can I help you with?',
    'build status': () => ({ type: 'dropdowns', message: 'Sure, Can you help me choose the LOB, Product, repo and branch.' }),
    // Add more commands here
};

async function runChat(prompt) {
    const command = commands[prompt.toLowerCase()];
    if (!command) {
        return 'Sorry, I did not understand that.';
    }
    try {
        return command();
    } catch (error) {
        console.error(error);
        return 'Sorry, something went wrong.';
    }
}

export default runChat;